<!DOCTYPE html>
<html>
<head>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
    body{

    background-color: #f205e4;
}

    .container{

    }
h1{
   
    color:#f9ff58;
}
.col-md-4{
text-align: center;
padding: 5px;
margin-top: 5px;

}
img{
    border:5px solid white;
}

</style>


</head>
<body>

</body>
</html>




<?php
session_start();
?>
<?php
include('connection.php');
$email=$_SESSION['email'];
$sql = "SELECT * FROM guest WHERE email='$email'"; 
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) 
{
    while($row = mysqli_fetch_assoc($result)) 
    {
    	?>
    	<div class="container">

    	<div class="col-md-4" ><span><b>Welcome:</b></span> &nbsp; <?php echo $row['fname'];?><?php echo $row['lname'];?> &nbsp;<img src="uploads/<?php echo $row['image'];?>" height="50px" width="50px"></div>
    	<div class="col-md-4"> <span><h1>**User Profile**</h1></span></div>
    	<div class="col-md-4"><a href="logout.php" style="text-decoration:none;"><button class="btn btn-success btn-lg">User Logout</button></a> </div>
        <div class="container">
        <div class="row">
        <div class="col-md-7">
        <table class="table table-border table-striped">
        	<tr>
        		<th>First Name</th>
        		<th>Last Name</th>
        		<th>Email</th>
        		<th>Password</th>
        		<th>Date of Birth</th>
        		<th>Contact</th>
        		<th>Gender</th>
                <th>Update</th>
        	</tr>
        	<tr>
        		<td><?php echo $row['fname'];?></td>
        		<td><?php echo $row['lname'];?></td>
        		<td><?php echo $row['email'];?></td>
        		<td><?php echo $row['password'];?></td>
        		<td><?php echo $row['dob'];?></td>
        		<td><?php echo $row['contact'];?></td>
        		<td><?php echo $row['gender'];?></td>
        		
                <?php $id = $row['email']; ?>
                <td><a href='edit.php?email=<?php echo $email; ?>'><button class="btn btn-primary">EDIT </button></a></td>
        	
            
            </tr>
        </table>
        </div>
        <div class="col-md-5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="uploads/<?php echo $row['image'];?>" height="300px" width="300px"></div>
        </div>
        </div>
        </div>
<?php        
    }
 ?>   
 <?php
} 
else 
{
    echo "0 results";
}	

?>
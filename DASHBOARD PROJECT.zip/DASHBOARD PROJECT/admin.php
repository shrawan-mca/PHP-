
<?php
session_start();
?>
<?php 
include('connection.php');
if (isset($_POST["submit"])) 
{
$username=$_POST['username'];
$password=$_POST['password'];
$sql = "SELECT * FROM admin WHERE username='$username' AND password='$password'";

	$check = mysqli_query($conn, $sql);
	$count = mysqli_num_rows($check);

	if ($count == 1) 
	{
		$_SESSION['username']=$username;
		header("location:display.php");
	

	}else{

		echo "<script>alert('Invalid User!')</script>";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
<div class="container-fluid">
<div class="row">
	<div class="col-md-4"><a href="login.php"><button  class="btn btn-lg btn-primary">User Login</button></a></div>
	<div class="col-md-4"><h3>**Admin Login**</h3></div>
	<div class="col-md-4"><a href="insert.php"><button class="btn btn-lg  btn-info">User Registration</button></a></div>
</div>
<div class="container">

<form method="POST" action="" class="form-horizontle" role="form" >
	
	
	<div class="form-group">
		<label>Admin Id:&nbsp;&nbsp;</label>
			<input type="text" class="form-control" name="username">
		</div>
	<div class="form-group">
		<label>Password:&nbsp;&nbsp;</label>	
			<td><input type="password" class="form-control" name="password"></td>
		</div>
		
	<div class="form-group">
		<input type="submit" name="submit" class="btn btn-success btn-lg" value="Login">
		<input type="reset" class="btn btn-danger btn-lg" class="btn btn-danger" value="Reset">
</div>
</form>
</div>

</body>
</html>
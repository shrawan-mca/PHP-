
<!DOCTYPE html>
<html>
<head>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">


<style>
    img {
    width: 180px;
    height: 180px;
}
</style>

</head>
<body>
<div class="container-fluid">
<div class="row">
    <div class="col-md-4"><span><h3><b>Welcome:</b> Admin</h3></span></div>
    <div class="col-md-4"><h3>**Registerd Users**</h3></div>
    <div class="col-md-4"><a href="admin.php"><button  class="btn btn-lg btn-primary">Admin Logout</button></a></div>
</div>
</body>
</html>

<?php
session_start();
?>
<?php
		include('connection.php');
		$sql = "SELECT * FROM guest";
		$result = mysqli_query($conn, $sql);  
        ?>



    <div class="container-fluid">
<div class="table-responsive">

        <table class="table table-bordered table-striped">

        <tr>
        <th>Number</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Date of Borth</th>
        <th>Contact</th>
        <th>Image</th>
        <th>Edit</th>
        <th>Delete</th>
        </tr>



<?php
if (mysqli_num_rows($result) > 0) {
    
    while($row = mysqli_fetch_assoc($result)) {

?>  


    	<tr>
    	<td> <?php echo $row["id"]; ?></td>
    	<td> <?php echo $row["fname"]; ?></td>
    	<td> <?php echo $row["lname"]; ?></td>
        <td> <?php echo $row["email"]; ?></td>
    	<td> <?php echo $row["password"]; ?></td>
        <td> <?php echo $row["dob"]; ?></td>
        <td> <?php echo $row["contact"]; ?></td>
        <td><img src="uploads/<?php echo $row["image"]; ?>"></td>
        <?php $id = $row['id']; ?>
        <td><a href='edit.php?id=<?php echo $id; ?>'><button class="btn btn-primary">EDIT </button></a></td>
        <td><a href='delete.php?id=<?php echo $id; ?>' ><button class="btn btn-danger">DELETE </button></a></td>
        </tr>
     

 <?php        
    }
?>

 </table> 
 </div>
 </div>



<?php

} else {
    echo "0 results";
}

?>
<?php
session_start();
?>
<?php
include('connection.php');
if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	$sql = "SELECT * FROM guest WHERE email='$email' AND password='$password'";

	$check = mysqli_query($conn, $sql);

	$count = mysqli_num_rows($check);

	if ($count == 1) 
	{
		$_SESSION['email']=$email;
		header("location:welcome.php");
	

	}else{

		echo "<script>alert('Invalid User!')</script>";
	}


}





?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body bgcolor="lightgreen">
<div class="container-fluid">
<div class="row">
	<div class="col-md-4"><a href="admin.php"><button  class="btn btn-lg btn-primary">Admin Login</button></a></div>
	<div class="col-md-4"><h3>**User Login**</h3></div>
	<div class="col-md-4"><a href="insert.php"><button class="btn btn-lg  btn-info">User Registration</button></a></div>
</div>

<div class="container">
<form class="form-horizontle" role="form"  method="POST" action="login.php">

	
<div class="form-group">
		<label for="email">Email ID:&nbsp;&nbsp;</label>
		<input type="email" class="form-control"  name="email" value="">
		</div>

<div class="form-group">
		<label for="password">Password: &nbsp;&nbsp;</label>
	<input type="password" class="form-control"  name="password" value="">
</tr>
<br>
<div class="form-group">
	<input type="submit" name="submit" class="btn btn-success btn-lg" value="Login">
	<input type="reset" name="reset" class="btn btn-danger btn-lg" class="btn btn-danger" value="Reset">
</div>
</form>
</div>
</body>
</html

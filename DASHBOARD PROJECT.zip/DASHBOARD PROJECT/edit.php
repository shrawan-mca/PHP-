<head>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>

</body>
</html>




<?php
session_start();
?>
<?php
include('connection.php');
$email = $_SESSION['email']; 
$query = "SELECT * FROM guest WHERE email='$email' ";
$result = mysqli_query($conn,$query);
if (mysqli_num_rows($result)>0) {
	
	while ($row=mysqli_fetch_assoc($result)) {
		
		?>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6">
					<span style="font-size:25px;">Welcome&nbsp;<?php echo $row['fname']?></span>
				</div>
				<div class="col-md-6" style="text-align:right;">
					<button class="btn btn-success"><a href="logout.php" style="text-decoration:none;">LOGOUT</a></button>
				</div>

			</div>
			<div class="table-responsive">
				<form action="" method="POST">
				<table class="table table-bordered">
				<th colspan="2" style="text-align:center">**USER PROFILE**</th>
					<tr>
		<th>First Name: </th>
		<td> <input type="text" name="fname" value="<?php echo $row['fname'];?>"/></td>
	</tr>

	<tr>
		<th>Last Name: </th>
		<td> <input type="text" name="lname" value="<?php echo $row['lname'];?>"/></td>
	</tr>


	<tr>
		<th>Email: </th>
		<td> <input type="email" name="email" value="<?php echo $row['email'];?>"/></td>
	</tr>

	<tr>
		<th>Password: </th>
		<td> <input type="password" name="password" value="<?php echo $row['password'];?>" /></td>
	</tr>

	<tr>
		<th>Date of Birth: </th>
		<td><?php echo $row['dob'];?></td>
	</tr>
	<tr>
		<th>Contact:</th>
		<td><input type="text" name="contact" value="<?php echo $row['contact'];?>"/></td>
	</tr>	
	
	<tr>
		<th>Gender:</th>
		<td><?php echo $row['gender'];?></td>
	</tr>	
	
	<tr>
	<th> Select image to upload:</th>
	<td><img src="uploads/<?php echo $row['image'];?>" height="100px" width="100px">
   		<input type="file" name="fileToUpload" id="fileToUpload" value="<?php echo $row['image'];?>"></td>
    </tr>

	<tr>
	<td colspan="2" align="center">
	<input type="submit" name="update" value="Update">
	</td>
	</tr>

				
				
				</table>
				</form>
			</div>

		</div>
		<?php
	}
}
else{

	echo "No result";
}
if (isset($_POST['update'])) 
{
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['password'];
$contact = $_POST['contact'];
$query = "UPDATE guest SET fname='$fname',lname='$lname',email='$email',password='$password',
contact='$contact' WHERE email='$email'";
if(mysqli_query($conn,$query))
{
	echo "<script>alert('Update')</script>";
	header("location:welcome.php");
}
else
{
	echo "not updated";
}

	
}	
?>
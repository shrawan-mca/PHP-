<?php

		$user= "root";
		$pass = "";
		$database = "dbtest";
		$host = "localhost";


		$conn = mysqli_connect($host , $user , $pass , $database );

		if (!$conn) {
    			die("Connection failed: " . mysqli_connect_error());
		}else{

			echo "";
		}

?>
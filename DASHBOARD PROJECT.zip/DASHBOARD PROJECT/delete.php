<?php
session_start();
?>

<?php
include('connection.php');
$id = $_GET['id'];

$sql = "DELETE FROM guest WHERE id='$id'";

if (mysqli_query($conn, $sql)) {
    echo header("location: display.php");
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}

mysqli_close($conn);
?>


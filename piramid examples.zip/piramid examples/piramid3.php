<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>trangle with for loop</h1>
<?php

$height = 15;

for($i=1;$i<=$height;$i++){

    for($t = 1;$t <= $height-$i;$t++)
    {
        echo "&nbsp;&nbsp;";
    }

    for($j=1;$j<=$i;$j++)
    {
                echo "*&nbsp;&nbsp;";
    }
echo "<br />";
}

?>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="" method="POST">

	Print the Number in Boxs :&nbsp;<input type="text" name="item">
	<input type="submit" name="submit" value="Print">

</form>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
	$abc = $_POST["item"];
	$item = strlen($_POST['item']);
	 $item1 =substr($abc,0,$item);
	for ($i=0; $i<$item; $i++) { 
	?>
	
	<input type="text" value="<?php echo $item1[$i];?>"/>;
	<?php
}
	
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>trangle with for loop</h1>

	<?php

for ($i=0; $i<5; $i++)
{
 for ($j=0; $j<=$i; $j++)
  {
   echo '* ';
  }
   echo "</br>";
}

?>
</body>
</html>
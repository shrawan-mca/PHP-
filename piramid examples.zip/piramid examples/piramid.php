<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<h1>Half piramid with *</h1>

<?php

for($i=0; $i<=5; $i++)
{
for($j=5-$i; $j>=1; $j--)
{
echo "* ";
}
echo "<br>";
}

?>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>trangle with for loop</h1>
<?php

$height = 5;

for($i=1;$i<=$height;$i++){

    for($t = 1;$t <= $height-$i;$t++)
    {
        echo "&nbsp;&nbsp;";
    }

    for($j=1;$j<=$i;$j++)
    {
                echo $j;
    }

    for ($k=1; $k <$i ; $k++) { 
    	
    	echo $k;
    }
echo "<br />";
}

?>
</body>
</html>